#include "main.hpp"

int main() {
	const int count = 1000000000;
		int i = 0;
		while(i < count) {
			std::cout << "Iteration number: " << i << std::endl;
			i++;
		}
		return 0;
}

