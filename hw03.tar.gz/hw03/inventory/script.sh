#!/bin/bash
ARG1=$1
########################################
# TODO COMMENT
rm -f sorted_inventory_name.csv
rm -f big_summer_blowout_sale.csv
rm -f stats.csv
# TODO COMMENT
if [[ $ARG1 == "reset" ]]; then
  echo "Cleaned up previous run files only..."
  echo "EXITING..."
  exit
fi

########################################
# TODO COMMENT
SHUF_INV="./shuf_inventory.csv"
# TODO COMMENT
NUM_LINES=$(wc -l $SHUF_INV | cut -d ' ' -f 1)
# TODO COMMENT
STATS="./stats.csv"

########################################
# TASK 0
# TODO COMMENT
echo "Statistic Type,Stat" > $STATS

########################################
# TASK 1
# TODO COMMENT
let "NUM_LINES=NUM_LINES-1"
# TODO COMMENT
head -n 1 $SHUF_INV > sorted_inventory_name.csv
# TODO COMMENT
tail -n $NUM_LINES $SHUF_INV | sort >> sorted_inventory_name.csv
# TODO COMMENT
echo "Total Products,$NUM_LINES" >> $STATS
########################################
# TASK 2
# TODO COMMENT
CITRUS=$(grep -i "Citrus" $SHUF_INV)
# TODO COMMENT
NUM_CITRUS=$(echo "$CITRUS" | wc -l)
# TODO COMMENT
echo "Total Citrus,$NUM_CITRUS" >> $STATS
# TODO COMMENT
CITRUS_1=$(echo "$CITRUS" | grep -E "[1]\.[0-9]{2}" | wc -l)
# TODO COMMENT
CITRUS_2=$(echo "$CITRUS" | grep -E "[0-2]\.[0-9]{2}" | wc -l)
# TODO COMMENT
echo "1.00 >= CITRUS >= 1.99,$CITRUS_1" >> $STATS 
# TODO COMMENT
echo "0.00 >= CITRUS >= 2.99,$CITRUS_2" >> $STATS
########################################
# TASK 3
# TODO COMMENT
echo "Products start with A,$(grep -E "^[Aa]" $SHUF_INV | wc -l)" >> $STATS
########################################
# TASK 4
# TODO COMMENT
INV_REGEX="s/[1]\.[0-5][0-9]$/1\.00/g"
sed -E $INV_REGEX sorted_inventory_name.csv > big_summer_blowout_sale.csv
########################################
# TASK 5
# TODO COMMENT
TEMP=$(grep -iv -f product_types.csv sorted_inventory_name.csv)
# TODO COMMENT
COUNT=$(echo "$TEMP" | wc -l)
# TODO COMMENT
let "COUNT=COUNT-1"
# TODO COMMENT
echo "Plastic Products,$COUNT" >> $STATS
########################################
# TASK 6
# TODO COMMENT
cat $STATS
